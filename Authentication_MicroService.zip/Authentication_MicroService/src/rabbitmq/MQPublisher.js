"use strict";
// Access the callback-based API

var amqp = require('amqplib');
var mqConfig = require('./mqconfig');

/**
 * Parse VCAP services objects, based on service type
 * @return RabbitMQ uri as returnObject
 */
var cfenv = require('cfenv');
var appEnv = cfenv.getAppEnv();

var logger = require('./../logs/applicationlogs.js');

var rabbitMQ_uri = (function () {
    //logger.log(JSON.stringify(appEnv));
    //get the service credentials by giving the service instance name
    if (appEnv.getService(mqConfig.rabbitmq_service_name)) {
        //logger.log('RABBIT MQ SERVICE AVAILABLE IN THIS PLATFORM');
        var uri = appEnv.getService(mqConfig.rabbitmq_service_name).credentials.uri;
        //logger.log('URI for RabbitMQ: '+uri);
        return uri;
    }
    else
    {
        //logger.log('error: No service name ' + mqConfig.rabbitmq_service_name + ' bound to the application. Connecting locally');
        return 'amqp://localhost';
    }
}());



/**
 * Set up a connection
 * create mq connection and channel to send messages. This will be done only once
 * @param callBack
 */
function createConnectionNSendMessage(message, queue, topicName,callBack) {
    //logger.log('Inside initConnection'+JSON.stringify(message));
    //logger.log(message);
    amqp.connect(rabbitMQ_uri + "?heartbeat=" + mqConfig.heartbeat).then(function(conn) {
        return conn.createChannel().then(function(ch) {
            console.log('chann');
            var ok = ch.assertQueue(queue, {durable: true});

            return ok.then(function(_qok) {
                // NB: `sentToQueue` and `publish` both return a boolean
                // indicating whether it's OK to send again straight away, or
                // (when `false`) that you should wait for the event `'drain'`
                // to fire before writing again. We're just doing the one write,
                // so we'll ignore it.
                ch.sendToQueue(queue, new Buffer(JSON.stringify(message)));
                console.log(' [x] Sent ' + message);
                return ch.close();
            });
        }).finally(function() {
            conn.close();
            callBack(null, {});
        });
    }).catch(console.warn);




};


// Global functions
exports.createConnectionNSendMessage = createConnectionNSendMessage;
