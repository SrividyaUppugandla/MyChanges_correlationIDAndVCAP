
var mqlight = require('mqlight');
var mqConfig = require('./mqconfig.json');
var logger = require('./../logs/applicationlogs.js');

/**
 * Set up a connection
 * create mq connection and channel to send messages. This will be done only once
 * @param callBack
 */
function createConnectionNSendMessage(message,queue, topicName, callBack) {
    var opts = {};
    var services = JSON.parse(process.env.VCAP_SERVICES);

    if (services['messagehub'] && services['messagehub'][0]) {
        var mqlightService = services['messagehub'][0];
        opts.service = mqlightService.credentials.mqlight_lookup_url; logger.log('opts.service: '+opts.service);
        opts.user = mqlightService.credentials.user; logger.log('opts.user: '+opts.user);
        opts.password = mqlightService.credentials.password; logger.log('opts.password: '+opts.password);
        var mqlightClient = mqlight.createClient(opts, function (err) {
            if (err)
            {
                logger.log('failed to connect to MQLight from consumer');
                callBack('failed to connect to MQLight from consumer');
            }
            else {
                logger.log('Successfully connected to MQLight from Publisher');
            }
        });
        mqlightClient.on('started', function () {
            logger.log('started with topic: '+ topicName);
            message = JSON.stringify(message);
          
                mqlightClient.send(topicName, new Buffer(message), function (error) {
                    if (error) {
                        logger.log('error while sending the message to message hub mqlight'+ error);
                        callBack(error);
                    }
                    else {
                        logger.log('Successfully sent to mqlight');
                        callBack(null, 'message successfully sent');
                        mqlightClient.stop();
                    }
                });
       
        });
    }
    else {
        logger.log('app has not binded to message hub');
    }
}


/**
 * Close the connection on error
 * @param err
 * @returns {boolean}
 */
function closeOnErr(err, mqlightClient) {
    if (!err) return false;
    logger.log('error [MessageHub] error: ' + err);
    mqlightClient.close();
    return true;
}


// Global functions
exports.createConnectionNSendMessage = createConnectionNSendMessage;
