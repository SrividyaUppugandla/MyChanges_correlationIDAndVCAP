/**
 * Created by trujun on 26/10/16.
 */

var mqHandler = undefined;
var logger = require('./../logs/applicationlogs.js');
var config = require('./mqconfig.json');


function getQueueHandler(){
    if (process.env.platform === 'Bluemix') {
        mqHandler = require('./MessageHub.js');
        console.log('Bluemix handler created successfully');
    }
    else if (process.env.platform === 'Cognizantfoundry') {
        mqHandler = require('./MQPublisher.js');
        console.log('Cognizantfoundry handler created successfully');
    }
}

function connectToQueueAndSendMessage(message, callback) {
    if (process.env.platform === 'Bluemix') {
        mqHandler = require('./MessageHub.js');
        console.log('Bluemix handler created successfully');
    }
    else if (process.env.platform === 'Cognizantfoundry') {
        mqHandler = require('./MQPublisher.js');
        console.log('Cognizantfoundry handler created successfully');
    }

    if (mqHandler) {
        console.log('**inside mqHandler object**');
        var correlationId;
        if (process.env.correlationId) {
            correlationId = process.env.correlationId;
        }
        else {
            correlationId = 'Authentication-MicroService';
        }
        var queue;
        var topicName;
        var objectToSendToConsumer;
        if (message && typeof(message) === Object && message.type){
            queue = config.registryQueue;
            topicName = config.registryTopicName;
            objectToSendToConsumer = message;
        }
        else {
            queue = config.queue;
            topicName = config.topicName;
            objectToSendToConsumer = { "level": "error", "appid": correlationId, "message": message, "priority": "low" };
        }
        
        console.log('***correlationId***'+correlationId+'**queue**'+queue);

        mqHandler.createConnectionNSendMessage(objectToSendToConsumer, queue, topicName, function (error, result) {
            if (error) {
                logger.log('error in createConnectionNSendMessage '+error);
                callback(error);
            }
            else {
                callback(null, '');
            }
        });
    }
    else {
        logger.log('Kindly check whether the platform is set properly in the environment variables');
    }
}

exports.connectToQueueAndSendMessage = connectToQueueAndSendMessage;
exports.getQueueHandler = getQueueHandler;