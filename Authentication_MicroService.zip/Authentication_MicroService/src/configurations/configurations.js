//to get VCAP configuration values.
exports.getVCAPConfigurations = function (callback) {
    var configObj = {};
    configObj.algorithm = 'sha512';
    var loggermarketplaceservname = 'Logger';
    var spacename = process.env.spacename;
    //checking for logger vcap service.
    if (JSON.parse(process.env.VCAP_SERVICES) && spacename) {
        var vcapServObj = JSON.parse(process.env.VCAP_SERVICES);
        //getting logger service name.
        var spacescopedbrokernameObj = vcapServObj[spacename + '_' + loggermarketplaceservname];
        if (spacescopedbrokernameObj && spacescopedbrokernameObj[0] && spacescopedbrokernameObj[0]["credentials"] && spacescopedbrokernameObj[0]["credentials"]["serviceurl"]) {
            configObj.loggerserviceURL = spacescopedbrokernameObj[0]["credentials"]["serviceurl"] + '/save';
            configObj.apikey = spacescopedbrokernameObj[0]["credentials"]["apiKey"];
            callback(null, configObj);
        }
        else {
            var domainscopedbrokernameObj = vcapServObj[loggermarketplaceservname];
            if (domainscopedbrokernameObj && domainscopedbrokernameObj[0] && domainscopedbrokernameObj[0]["credentials"] && domainscopedbrokernameObj[0]["credentials"]["serviceurl"]) {
                configObj.loggerserviceURL = domainscopedbrokernameObj[0]["credentials"]["serviceurl"] + '/save';
                configObj.apikey = domainscopedbrokernameObj[0]["credentials"]["apiKey"];
                callback(null, configObj);
            }
            else {
                console.log('***App has not been binded to logger service***');
            }
        } 
    }
    else {
        console.log('***App has not been binded to logger service***');
    }
}