/**
 * Created by trujun on 12/09/16.
 */

'use strict';
var request = require('request');
var config = require('./config');
const crypto = require('crypto');
var apiKey;

function computeHash(algorithm, secret, contentToHash){
    return crypto
        .createHmac(algorithm, secret)
        .update(contentToHash)
        .digest('hex')
}

exports.validateAPIKey = function(req,res,next) {
    console.log('Inside validateAPIKey');
    var dateKey = req.headers.datekey;
    var receivedHash = req.headers.hashcode;
    var nonce = req.headers.nonce;

    console.log('-----> request.headers.date: '+ dateKey);
    console.log('-----> request.headers.hashcode: '+ receivedHash);
    console.log('-----> request.headers.nonce: '+nonce);


    var vaultKey = process.env.vaultkey;
    var vaultDB = process.env.vaultdb;
    fetchAPIKeyFromVault(vaultKey, vaultDB, function(err, statusCode, body){
        if(err){
            res.send(400, {'error': 'Access forbidden from VAULT'});
        }
        else if(statusCode === 200){
            var resultJSON = JSON.parse(body);
            console.log('result: '+resultJSON.apikey);
            apiKey = resultJSON.apikey;
        }


        console.log('API KEY: '+apiKey);

        var algorithm = config.Hash.algorithm;
        var httpInput;

        var contype = req.headers['content-type'];
        if (!contype || contype.indexOf('application/json') !== 0)
        {
            res.status(400).json(
                {
                    status:'Invalid JSON',
                    message:'** content-type should be application/json'
                }
            )
        }
        else
        {
            if (req.body && req.method !== 'GET') {
                httpInput = JSON.stringify(req.body);
            }
            else {
                httpInput = JSON.stringify(req.url);
            }
        }

        if(dateKey && nonce && apiKey && httpInput !== undefined)
        {
            var contentToHash = apiKey + dateKey + nonce + httpInput;
            console.log('content: '+contentToHash);
            if (receivedHash === undefined || contentToHash === undefined) {
                res.status(403);
                res.send({'error': 'Access forbidden'});

            }

            var computedHash = computeHash(algorithm, apiKey, contentToHash);
            console.log('computedHash: ' + computedHash);

            if (receivedHash === computedHash) {
                next();
            }
            else
            {

                res.setHeader("Access-Control-Allow-Headers", "*");
                res.setHeader('Content-Type', 'application/json');
                res.setHeader("Access-Control-Allow-Origin", "*");
                res.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, PUT, DELETE");
                //res.send({error:"Not Authorised. Invalid apiKey"}, 401);
                res.status(403);
                res.send({'error': 'Access forbidden'});
            }
        }
        else
        {
            res.status(400);
            res.send({'error': 'Bad Request'});
        }
    });
};


function fetchAPIKeyFromVault(vaultKey, vaultDB, callback){
    request({
        url: config.vault.url, //URL to hit
        method: 'GET', //Specify the method
        headers: { //We can define headers too
            'Content-Type': 'application/json',
            'vaultkey':vaultKey,
            'vaultdb':vaultDB
        }
    }, function(error, response, body){
        if(error) {
            console.log('ERROR IN FETCHING VAULT RES: '+error);
            callback(error);
        } else {
            console.log(response.statusCode, body);
            callback(error, response.statusCode, body);
        }
    });
}


