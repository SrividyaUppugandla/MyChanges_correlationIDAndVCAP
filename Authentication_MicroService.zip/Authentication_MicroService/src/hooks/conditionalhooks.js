var async = require('async');
var vm = require('vm');
var logger = require('./../logs/applicationlogs.js');
var ConditionalHooks = function () {
};

ConditionalHooks.prototype.compareHooksCondition = function (req, resultedTokenDetails, compareHooksConditionCallback) {
    logger.log('**inside compareHooksCondition function**');
    //getting the condtional hooks objects from environment variables
    if (process.env["config"] && resultedTokenDetails) {
        var processConfig = JSON.parse((process.env["config"]).replace(/=>/g, ':'));
        var hookType = resultedTokenDetails["hookType"];
        if (hookType === "prehook") {
            hookType = "prehooks";
        }
        else if (hookType === "posthook") {
            hookType = "posthooks";
        }
        var authenticationType = resultedTokenDetails["authenticationType"];
        var currentHook = resultedTokenDetails["currentHook"] - 1;
        //checking whether the provider exists in config of environment JSON.
        if (processConfig[hookType][authenticationType]) {
            //getting the condition array from environment variables
            var condition = processConfig[hookType][authenticationType][currentHook]["condition"];
            //if condition is available for the current prehooks form the condition expression.
            if (condition) {
                var configuredCondition, headersConfiguredCondition;
                var notEqualObjects = {};
                //looping all the conditions to from expression.
                async.each(condition, function (conditionObj, asyncCallback) {

                    var conditionKeyName = conditionObj["key"].toLowerCase();
                    var conditionOperator = decodeURIComponent(conditionObj["operator"]);
                    var conditionValue = conditionObj["value"];
                    logger.log(typeof (conditionValue));
                    var conditionOperand = conditionObj["operand"];

                    if (conditionOperator === '!=') {
                        notEqualObjects[conditionKeyName] = conditionValue;
                    }

                    if (configuredCondition && configuredCondition.length) {
                        if (Number(conditionValue)) {
                            configuredCondition = configuredCondition + ' ' + conditionKeyName + ' ' + conditionOperator + ' ' + conditionValue + ' ';
                        }
                        else {
                            configuredCondition = configuredCondition + ' ' + conditionKeyName + ' ' + conditionOperator + ' \'' + conditionValue + '\' ';
                        }
                    }
                    else {
                        if (Number(conditionValue)) {
                            configuredCondition = conditionKeyName + ' ' + conditionOperator + ' ' + conditionValue + ' ';
                        }
                        else {
                            configuredCondition = conditionKeyName + ' ' + conditionOperator + ' \'' + conditionValue + '\' ';
                        }
                    }

                    logger.log('**configuredCondition**'+configuredCondition);

                    if (conditionOperand) {
                        configuredCondition = configuredCondition + ' ' + conditionOperand;
                    }
                    logger.log('**final configuredCondition**'+configuredCondition);

                    // Async call is done, alert via callback
                    asyncCallback();
                },
                    function (err) {
                        if (err) {
                            logger.log('**ERROR in final configuredCondition**');
                            compareHooksConditionCallback(err);
                        }
                    }
                );

                //loop for request headers to from expression based on configured key of environment variables.
                async.each(condition,
                    function (requestConditionObj, requestConditionObjCallback) {
                        var key = [requestConditionObj["key"]].toString().toLowerCase();
                        if (req["headers"][key]) {
                            if (headersConfiguredCondition && headersConfiguredCondition.length && headersConfiguredCondition.indexOf(key) === -1) {
                                if (Number(req["headers"][key])) {
                                    headersConfiguredCondition = headersConfiguredCondition + ' ' + key + ' = ' + ' ' + req["headers"][key] + '; ';
                                }
                                else {
                                    headersConfiguredCondition = headersConfiguredCondition + ' ' + key + ' = ' + '\'' + req["headers"][key] + '\';';
                                }
                            }
                            else if (headersConfiguredCondition === undefined) {
                                if (Number(req["headers"][key])) {
                                    headersConfiguredCondition = "" + key + ' = ' + ' ' + req["headers"][key] + '; ';
                                }
                                else {
                                    headersConfiguredCondition = "" + key + ' = ' + '\'' + req["headers"][key] + '\';';
                                }
                            }
                        }
                        else {
                            if (headersConfiguredCondition && headersConfiguredCondition.length && headersConfiguredCondition.indexOf(key) === -1) {
                                if (notEqualObjects && notEqualObjects.hasOwnProperty(key)) {
                                    if (notEqualObjects && Number(notEqualObjects[key])) {
                                        headersConfiguredCondition = headersConfiguredCondition + ' ' + key + ' = ' + notEqualObjects[key] + ';';
                                    }
                                    else {
                                        headersConfiguredCondition = headersConfiguredCondition + ' ' + key + ' = ' + '\'' + notEqualObjects[key] + '\';';
                                    }
                                }
                                else {
                                    headersConfiguredCondition = headersConfiguredCondition + ' ' + key + ' = ' + '\'' + null + '\';';
                                }
                            }
                            else if (headersConfiguredCondition === undefined) {
                                if (notEqualObjects && notEqualObjects.hasOwnProperty(key)) {
                                    if (notEqualObjects && Number(notEqualObjects[key])) {
                                        headersConfiguredCondition = "" + key + ' = ' + notEqualObjects[key] + ';';
                                    }
                                    else {
                                        headersConfiguredCondition = "" + key + ' = ' + '\'' + notEqualObjects[key] + '\';';
                                    }
                                }
                                else {
                                    headersConfiguredCondition = "" + key + ' = ' + '\'' + null + '\';';
                                }
                            }
                        }
                        // Async call is done, alert via callback
                        requestConditionObjCallback();
                    },
                    function (err) {
                        // All tasks are done now

                        if (err) {
                            logger.log('**ERROR in final requestConditionObj**');
                            compareHooksConditionCallback(err);
                        }
                    }
                );
                logger.log('**headersConfiguredCondition**'+headersConfiguredCondition);
            }
        }
    }

    //conditional hooks check. If we have conditional hook from request header & environment variable and eval of expression is true than we will generate the otp.
    //or if we have conditional hook from request header we will generate the otp
    //or If we don't have conditional hook from request header & environment variable we will generate the otp
    //Otherwise execution will skip and go to nextCall.
    var isExecutePreHooks = false;

    if (configuredCondition && headersConfiguredCondition) {
        headersConfiguredCondition = headersConfiguredCondition + configuredCondition;
        //isExecutePreHooks = eval(headersConfiguredCondition);
        var context = vm.createContext();
        var script = new vm.Script(headersConfiguredCondition);
        isExecutePreHooks = script.runInContext(context);
    }
    else if (!(configuredCondition || headersConfiguredCondition)) {
        isExecutePreHooks = true;
    }

    //call back to previous function call
    compareHooksConditionCallback(null, isExecutePreHooks);
};

module.exports = ConditionalHooks;