/**
 * Created by cognizant on 02/11/16.
 */
var serviceInfo;
var serviceInfo = (process.env.VCAP_APPLICATION && JSON.parse(process.env.VCAP_APPLICATION));
var uuid = require('uuid');
var node = uuid.v1();

var queueConnector = require('./../rabbitmq/QueueAdapter.js');
var constants = require('./../constants.json');

// var queue = "REGISTRY";
// var topicName = "REGISTRY";


if (process.env.VCAP_APPLICATION && JSON.parse(process.env.VCAP_APPLICATION)) {
    serviceInfo = JSON.parse(process.env.VCAP_APPLICATION);
    serviceInfo.node = node;
    serviceInfo.Tags = ["Authentication Microservice", "Oauth"];
}


var Registry = function () {

};

var sendMessage = function (serviceInfo, callback) {


    // mqConnector.queueHandler(function (err, queueHandler) {
    //     if (!err) {

    //         queueHandler.createConnectionNSendMessage(serviceInfo, queue, topicName, function (err, result) {
    //             if (err) {
    //                 console.log('Error in initialization: ' + err);
    //             }
    //             else {
    //                 console.log(serviceInfo);
    //                 console.log("message send successfully");
    //                 console.log(result);
    //             }
    //             callback();
    //         });
    //     }
    //     else {
    //         console.log('Error in creating MQ' + err);
    //         callback();
    //     }
    // });

    //If debugmode is queue sending logs to Queue otherwise calling registry register/deregister api's
    if (process.env.debugmode && process.env.debugmode === constants.DEBUG_MODE_QUEUE) {
        queueConnector.connectToQueueAndSendMessage(serviceInfo, function (error, result) {
            if (error) {
                console.log('Error in initialization: ' + error);
            }
            else {
                console.log(serviceInfo);
                console.log("message send successfully");
                console.log(result);
            }
            callback();
        });
    }
    else {
        if (serviceInfo.type === 'REGISTER') {
            //calling register api
            
        }
        else {
            //calling deregister api
        }
    }


};

Registry.prototype.registerService = function () {
    if (process.env.VCAP_APPLICATION) {
        delete serviceInfo.type;
        serviceInfo.type = 'REGISTER'
        console.log("REGISTER")
        sendMessage(serviceInfo, function (err) {
            if (err) {
                console.log(err);
            }
            else {
                console.log("Service registered successfully")
            }

        });
    }
    else {
        console.log("No Vcap info present");
    }


};

Registry.prototype.deregisterService = function (err) {
    if (process.env.VCAP_APPLICATION) {
        delete serviceInfo.type;
        console.log("Got event to de register the Service --- Reason : " + err);
        serviceInfo.type = 'DEREGISTER'
        console.log("DEREGISTER")
        sendMessage(serviceInfo, function () {
            if (err) {
                console.log(err);
            }
            else {
                console.log("Service de-registered successfully");
            }

        });
    }
    else {
        console.log("No Vcap info present");
    }

};

module.exports = Registry;
