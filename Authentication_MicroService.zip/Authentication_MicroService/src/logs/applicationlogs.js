/**
 * Created by trujun on 23/11/16.
 */
var constants = require('./../constants.json');
var queueConnector = require('./../rabbitmq/QueueAdapter');
var vcapConfigObj = require('./../configurations/configurations.js');
var request = require('request');

var uuid = require('uuid');
const crypto = require('crypto');

function computeHash(algorithm, secret, contentToHash){
    return crypto
        .createHmac(algorithm, secret)
        .update(contentToHash)
        .digest('hex')
}

function sendMessageToLogger(message, vcapObject, callback) {

    //forming logger object
    var loggerObj = { "level": "error", "appid": process.env.correlationId, "message": message, "priority": "low" };
    var dateKey = new Date().getTime();
    var nonce = uuid.v1();
    var algorithm = vcapObject.algorithm;
    var httpInput = JSON.stringify(loggerObj);
    var apikey = vcapObject.apikey;
    var hashContent = apikey + dateKey + nonce + httpInput;
    var computedHash = computeHash(algorithm, apikey, hashContent);

    console.log('****computedHash****'+computedHash+'**dateKey**'+dateKey+'**nonce**'+nonce);
    //forming http request string
    var postOptions = {
        url: vcapObject.loggerserviceURL,
        method: 'POST',
        headers: {
            "datekey": dateKey,
            "hashcode": computedHash,
            "nonce": nonce,
            "Content-Type": 'application/json'
        },
        body:httpInput
    };

    request(postOptions, function (err, response) {
        if (err) {
            return callback(err);
        }
        else {
            return callback(null, response);
        }
    });
}


exports.log = function (message) {
    //console.log('**value of debugmode**',constants.logs.debugMode);
    if (process.env.debugmode && process.env.debugmode === constants.DEBUG_MODE_QUEUE) {
        console.log('**debugmode is queue');
        queueConnector.connectToQueueAndSendMessage(message, function (error, result) {
            if (error) {
                console.log('error in connectToQueueAndSendMessage ' + error);
            }
        });
    }
    else if (process.env.debugmode && process.env.debugmode === constants.DEBUG_MODE_LOOGER) {
        console.log('**debugmode is Logger');
        vcapConfigObj.getVCAPConfigurations(function (error, vcapObject) {
            console.log('***vcap object***',vcapObject);
            if (vcapObject && vcapObject.loggerserviceURL && vcapObject.apikey) {
                sendMessageToLogger(message, vcapObject, function(error, result) {
                    if (error) {
                        console.log('**error while saving logs to Logger**');
                    }
                    else {
                        console.log('**log saved successfully**');
                    }
                });
            }
            else {
                console.log('app has not binded to Logger');
            }
        });
    }
    else if (process.env.debugmode && process.env.debugmode === constants.DEBUG_MODE_CONSOLE) {
        console.log('**debugmode is console');
        var correlationId;
        if (process.env.correlationId) {
            correlationId = process.env.correlationId;
        }
        else {
            correlationId = 'Authentication-MicroService';
        }
        console.log(correlationId + ' : ' + message);
    }
    else {
        console.log('debugmode is not set in environment variable');
    }
}



