//dependencies
var bodyParser = require('body-parser');
var jsonParser = bodyParser.json();
var ldapHelper = require('./ldapHelper');
var authProvider = require('./../middleware/auth-provider');
var jwtVerifyPrehooks = require('./../../jwt/verifyHooks');
var verify = require('./../middleware/verify');
var jwt = require('./../../jwt/jwt');
var constants = require('./../../constants.json');
var async = require('async');
var logger = require('./../../logs/applicationlogs.js');
//constructor
var ldap = function () {

};


//Read the config key value from env variables. This will return a JSON string with '=>' symbol in place of ':'
//Replace '=>' symbol with ':' to convert to JSON string and parse to retrieve JSON object
var envJson;
var config;
if(process.env.config) {
    envJson = process.env.config;
    envJson = envJson.replace(/=>/g, ':');
    config = JSON.parse(envJson);
}

// These APIs are used to authenticate against an ldap server
ldap.prototype.ldapAuthenticate = function (app) {

    // POST /auth/ldap
    //   This API is the initial call for performing the authentication to ldap
    //   It check for any available prehooks information and creates JWT token based on prehooks information
    //   If no prehooks are available then JWT token is generated with next call information to authenticate with ldap
    //  If any prehooks are available then returns token and status code as 303
    app.post('/auth/ldap', [jsonParser,jwtVerifyPrehooks.verifyApiKey], function (req, res) {
            var provider = "ldap";
            authProvider.authProvider(provider,function(response) {
                res.setHeader("Status-Code", 200);
                res.setHeader("Access-Control-Allow-Headers", "*");
                res.setHeader('Content-Type', 'application/json');
                res.setHeader("Access-Control-Allow-Origin", "*");
                res.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, PUT, DELETE");
                res.send(response.responseJson, response.statusCode);
            });
        }
    );


    // route for ldap authentication
    // POST /ldap
    //  This API requires Token(generated from /auth/ldap call), dn, password in headers as inputs
    //  This API authenticates the user against ldap and returns the result.
    //  If no posthooks are available then returns the result with status 200
    //  If any posthooks are available then returns the nextCall, token with status as 303
    app.post("/ldap", [jsonParser,verify.verifyLdapRequest,jwtVerifyPrehooks.verifyPrehooksClearanceForLdap], function (req, res) {
        var userProfile ={};
        var configDetails = {
            ldapUrl     : config.configuration.ldap.ldapURL,
            logger      : "logger"   //TODO :: Check what is this logger parameter
        };
        var userDetails = {
            userName    : decodeURIComponent(req.headers.dn),
            password    : decodeURIComponent(req.headers.password)
        };

        //Call authenticate method
        var ldapHelperObj = new ldapHelper();

        var attributes_to_fetch = config.configuration.ldap.attributes_to_fetch;
        var filter_attributes = config.configuration.ldap.filter_attributes;
        var baseDN = decodeURIComponent(config.configuration.ldap.baseDN);
        var filterFromConfig = decodeURIComponent(config.configuration.ldap.filter);


        var waterfallCallback = function(err,results){
            if(err) {
                logger.log(JSON.stringify(err));
                return res.send(err,400);
            }
            else if(results) {
                return res.send(results.responseJson,results.status);
            }
            else {
                return res.send({error:"Something went wrong with LDAP authentication"},400);
            }
        };


        //check for all required parameters and configurations from request body and config.
        //If present then authenticate and get user details by applying filter

        //case1 : where useFilter is true. Pass all filter attributes in body.
        if(req.body && req.body.useFilter && req.body.useFilter === true) {

            var filterForConstruct = filterFromConfig;
            var constructFilter = function(constructFilterCallback) {

                async.each(filter_attributes,
                    function(filter_attribute, asyncCallback){
                        if(req.body[filter_attribute]) {
                            var search_attribute = "<"+filter_attribute+">";
                            var replace_value = req.body[filter_attribute];
                            filterForConstruct = filterForConstruct.replace(search_attribute,replace_value);
                            asyncCallback();
                        }
                        else {
                            asyncCallback({error : "Invalid filter_attributes passed/filter_attributes missing"});
                        }
                    },
                    function(err){
                        if(err) {
                            return constructFilterCallback(err);
                        }
                        // All tasks are done. now take the constructed filter and send back
                        configDetails.baseDN = baseDN;
                        configDetails.attributes_to_fetch = attributes_to_fetch;
                        configDetails.filter = filterForConstruct;
                        return constructFilterCallback(null,userDetails,configDetails);
                    }
                );
            };

            if(baseDN && filterFromConfig && attributes_to_fetch && filter_attributes) {
                // Here the control flow for constructing filter, authentication and preparing JSON response
                async.waterfall([constructFilter,authenticateUserForProfile,getLdapResponse],waterfallCallback);
            }
            else {
                return res.send({error:"Required configuration settings are missing", message : "Please check whether 'baseDN', 'filter', 'filter attributes' and 'attributes to fetch' settings enabled from command center"},400);
            }
        }
        //case2 : where useFilter is false. Pass filter in body.
        else if(req.body && req.body.useFilter === false) {

            var filterFromBody = req.body.filter;

            var passValuesForAuthenticate = function(passValuesForAuthenticateCallback) {
                configDetails.baseDN = baseDN;
                configDetails.attributes_to_fetch = attributes_to_fetch;
                configDetails.filter = filterFromBody;
                return passValuesForAuthenticateCallback(null,userDetails,configDetails);
            };

            if(baseDN && filterFromBody && attributes_to_fetch) {
                // Here the control flow for authentication and preparing JSON response
                async.waterfall([passValuesForAuthenticate,authenticateUserForProfile,getLdapResponse],waterfallCallback);
            }
            else {
                return res.send({error:"Required configuration settings are missing", message : "Please check whether 'baseDN' and 'attributes to fetch' settings enabled from command center. Also check if filter is passed in body parameter"},400);
            }
        }
        else if(req.body.useFilter) {
            return res.send({error:"Invalid value sent for useFilter", message : "useFilter can accept only boolean values either true or false"},400);
        }
        //case3 : where only authentication is required without any user profile.
        else {
            ldapHelperObj.authenticate(configDetails,userDetails, function(error, authFlag) {
                if (error === null && authFlag === true) {

                    //Prepare the response JSON for successful authentication
                    userProfile = {
                        "message": "authentication successful",
                        "authFlag": true
                    };

                    //Check if any posthooks are available then process the JSON and give next call with token.
                    // Else just share the details of user if any attributes are present in ldap config
                    getLdapResponse(userProfile,function(err,ldapResponse) {
                        res.setHeader("Access-Control-Allow-Headers", "*");
                        res.setHeader('Content-Type', 'application/json');
                        res.setHeader("Access-Control-Allow-Origin", "*");
                        res.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, PUT, DELETE");
                        res.send(ldapResponse.responseJson,ldapResponse.status);
                    });
                }
                else {
                    logger.log('Something wrong with authentication for dn '+req.headers.dn +' : '+JSON.stringify(error));
                    res.setHeader("Access-Control-Allow-Headers", "*");
                    res.setHeader('Content-Type', 'application/json');
                    res.setHeader("Access-Control-Allow-Origin", "*");
                    res.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, PUT, DELETE");
                    res.send(error, 401);
                }
            })
        }
    });
};

function getLdapResponse(userProfile,callback){
    //Check if any posthooks are available then process the JSON and give next call with token.
    // Else just share the details of user if any attributes are present in ldap config
    if ( config.posthooks && config.posthooks["ldap"]) {
        var authenticationType = "ldap";
        var postHooks = config.posthooks[authenticationType];
        var totalNoOfPosthooks = postHooks.length;
        var hookType = "posthook";

        var nextCall;
        var channel = postHooks[0].channelprovider;

        if (postHooks[0].channel === 'OTP') {
            nextCall = '/generateOtp'
        }
        if (postHooks[0].channel === 'Captcha') {
            nextCall = '/generateCaptcha'
        }

        if (postHooks[0].channel === 'WebApIHook') {
            nextCall = '/webabi/generate/*'
        }
        //Prepare JWT json info with totalNoOfPrehooks, preHooks object, currentPreHook(array number), authentication type(facebook), preparedBy(/auth/facebook)
        var jwtInfo = {
            userProfile     : userProfile,
            totalNoOfhooks  : totalNoOfPosthooks,
            hooks           : postHooks,
            currentHook     : 1,
            hookType        : hookType,
            authenticationType: authenticationType,
            nextCall        : nextCall,
            channelprovider : channel,
            iat             : Math.floor(Date.now() / 1000) - 30, //backdate a jwt 30 seconds to compensate the next execution statements
            expiresIn       : constants.expiresIn
            //preparedBy          :   authenticationType
        }

        // sign JWT token
        jwt.generateJWT(jwtInfo, function (err, token) {
            //Prepare jwt payload info json with all required values like nextcall, channel, jwt-token
            var responseJson = {
                nextCall            : nextCall,
                channelprovider     : channel,
                token               : token
            };

            var ldapResponse = {
                responseJson    : responseJson,
                status          : 303
            };
            callback(null,ldapResponse);
        });
    }
    else {
        var ldapResponse = {
            responseJson    : userProfile,
            status          : 200
        };
        callback(null,ldapResponse);
    }
}

// Function for authentication and then search for user profile.
//If more than one user profile found then throw error. Also if no user profile found then throw error
function authenticateUserForProfile(userDetails,configDetails, authenticateUserForProfileCallback) {
    var ldapHelperObj = new ldapHelper();
    ldapHelperObj.getUserDetails(userDetails,configDetails,function(bindError, searchError, searchResult) {
        if(bindError) {
            return authenticateUserForProfileCallback(bindError)
        }
        else if(searchError) {
            return authenticateUserForProfileCallback(searchError);
        }
        else if(searchResult.length === 1){
            return authenticateUserForProfileCallback(null,searchResult[0]);
        }
        else {
            return authenticateUserForProfileCallback({error:"No user profile found",message:"Please check filter settings."})
        }
    });
}

module.exports = ldap;


