module.exports = LDAPHelper;

var ldap = require('ldapjs');
function LDAPHelper() {
}

var logger = require('./../../logs/applicationlogs.js');

//Public function to be used for authentication
//  Below parameters are required for this function  
//      configDetails object - ldapUrl, logger
//      userDetails object   - userName, password
LDAPHelper.prototype.authenticate = function (configDetails, userDetails, callback) {
    var ldapURL = configDetails.ldapUrl;
    var clientUserName = userDetails.userName;
    var clientPassword = userDetails.password;
    var logger = configDetails.logger;
    clientBind(clientUserName, clientPassword, ldapURL, logger, function (error, authFlag, client) {
        if(error) {
            logger.log(error.message);
            callback(error, authFlag);
        }
        else {
            client.unbind();
            callback(error, authFlag);
        }
    })
}

//Private function for user bind check against ldap
function clientBind(userName, password, ldapUrl, logger, callback) {
    var authenticationFlag = false;
    var authClient;
    authClient = ldap.createClient({
        "url": ldapUrl
    });
    
    authClient.on('error', function(err){
        if(err) {
            callback(err,authenticationFlag,authClient);
        }
        else {
            callback({message: "error in connecting to LDAP server"},authenticationFlag,authClient);
        }
    });    
    
    try {
        authClient.bind(userName, password, function (err) {
            if (err) {
                callback(err, authenticationFlag, authClient);
            }
            else {
                authenticationFlag = true;
                callback(err, authenticationFlag, authClient);
            }
        });
    }
    catch(error) {
        logger.log(error);
        callback(error, authenticationFlag, authClient);
    }
}

// Public function for getting user details
LDAPHelper.prototype.getUserDetails = function (userDetails, configDetails, callback) {

    clientBind(userDetails.userName, userDetails.password, configDetails.ldapUrl, configDetails.logger, function (bindError, authenticationFlag, adminUser) {
        var logger = configDetails.logger;
        if (bindError === null) {
            var opts = {
                "filter" : configDetails.filter,
                "sizeLimit" : 1,
                "scope": "sub",
                "attributes": configDetails.attributes_to_fetch
            };

            clientSearch(configDetails.baseDN, adminUser, opts, configDetails.logger, function (searchResult, searchError) {
                adminUser.unbind();
                callback(bindError, searchError, searchResult);
            })
        }
        else {
            adminUser.unbind();
            callback(bindError, null, null);
        }
    })
};

//Private function for searching an user/group against an LDAP server
function clientSearch(baseDN, adminUser, opts, logger, callback) {
    var searchResult = [];
    try {
        adminUser.search(baseDN, opts, function (err, res) {
            res.on('searchEntry', function (entry) {
                var eachEntry = entry.object;
                delete eachEntry.controls;
                searchResult.push(eachEntry)
            });
            res.on('error', function (err) {
                return callback(searchResult, err);
            });
            res.on('end', function () {
                return callback(searchResult, err);
            });
        });
    }
    catch(ex) {
        return callback(searchResult, {error:"User profile search error. Check filter/baseDN settings",message:ex.message});
    }
}

// Public function for getting group details
LDAPHelper.prototype.getGroupDetails = function (configDetails, groupName, callback) {
    clientBind(configDetails.userName, configDetails.password, configDetails.ldapUrl, configDetails.logger, function (bindError, authenticationFlag, adminUser) {
        if (bindError === null) {
            var opts = {"filter": "(&(objectCategory=Group)(cn=" + groupName + "))",
                "scope": "sub",
                "attributes": ["objectCategory", "distinguishedName", "cn", "description", "member"]};
            clientSearch(configDetails.baseDN, adminUser, opts, configDetails.logger, function (searchResult, searchError) {
                adminUser.unbind();
                callback(bindError, searchError, searchResult);
            })
        }
        else {
            adminUser.unbind();
            callback(bindError, null, null);
        }
    });
}
