#!/bin/bash
cp -f lib/strategy.js node_modules/passport-oauth2/lib/strategy.js